package com.lwdHouse;

import java.io.*;

/**
 * FilterInputStream
 *  是装饰器模式
 */
public class Part04_Filter {

    public static void main(String[] args) throws IOException {

        try(CountInputStream cis = new CountInputStream(new FileInputStream("./javaCE_08/pom.xml"))){
            int n;
            while ((n = cis.read()) != -1){
                System.out.print((char) n);
            }
            System.out.println("\n总共读取"+cis.getBytesRead()+"字节");
        }
    }
}


class CountInputStream extends FilterInputStream{

    private int count = 0;

    protected CountInputStream(InputStream in) {
        super(in);
    }

    public int getBytesRead(){
        return count;
    }

    @Override
    public int read() throws IOException {
        int n = in.read();
        if (n != -1){
            count++;
        }
        System.out.println("\n读了a");
        return n;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int n = in.read(b, off, len);
        if (n != -1){
            count += n;
        }
        return n;
    }
}